import React from 'react'

const Newcompo = () => {
  return (
    <>
    
    </>
  )
}

export default Newcompo
