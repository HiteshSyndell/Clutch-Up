import React from "react";

const PageNotFound = () => {
    return (
        <div className="container">
            <h1>Page not Found</h1>
        </div>
    )
}

export default PageNotFound;