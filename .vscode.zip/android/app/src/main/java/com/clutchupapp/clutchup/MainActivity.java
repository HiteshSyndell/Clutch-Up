package com.clutchupapp.clutchup;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
